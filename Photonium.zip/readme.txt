Photonium.exe
------------------
Made by xuepiao (a.k.a. Compaq DeskPro2000)
It has skidded 7 payloads and sounds only
:)

MBR from Memoxide by WilliamP692?